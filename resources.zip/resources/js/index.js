$(function(){
	
	//$( "div.chatbox" ).draggable();
	$('div.chatbox').draggable({ cancel: '.cancel_drag'}); 

	$('.upload-form-click').on('click',function(){
		$('#upload-form #uploadfile').trigger('click');
	});
	
	
	$("img").mousedown(function(){
	    return false;
	});
	
	
  $('.fa-minus').click(function(){
	 
	  $(this).closest('.chatbox').toggleClass('chatbox-min');
	  if($(this).closest('.chatbox').hasClass('chatbox-min')){
		 
		  $('#chat_here').text("Chat Here..."); 
		
		$(this).closest('.chatbox-icons a:first-child i').removeClass('fa-minus').addClass('fa-plus');

		$("div.chatbox").draggable({ disabled: true });
		$(this).closest('.chatbox').find('.popup-head').addClass('hide');
		$(this).closest('.chatbox').find('.chat-input-holder').addClass('hide');
		$(this).closest('.chatbox').find('.attachment-panel').addClass('hide');
		$(this).closest('.chatbox').find('.attachment-panel').next().addClass('hide');
		$(this).closest('.chatbox').find('#chat').addClass('hide');
		$(this).closest('.chatbox').find('.chat-messages').css('display','none');
		$(this).closest('.chatbox').find('.footer').css('display','none');
	  }else{
		  $('#chat_here').text("EDA"); 
		
		$(this).closest('.chatbox-icons a:first-child i').removeClass('fa-plus').addClass('fa-minus');		
		$(this).closest('.chatbox').find('.popup-head').removeClass('hide');
		$(this).closest('.chatbox').find('.chat-input-holder').removeClass('hide');
		$(this).closest('.chatbox').find('.attachment-panel').removeClass('hide');
		$(this).closest('.chatbox').find('.attachment-panel').next().removeClass('hide');
		$(this).closest('.chatbox').find('#chat').removeClass('hide');	
		$(this).closest('.chatbox').find('.chat-messages').css('display','flex');
		$(this).closest('.chatbox').find('.footer').css('display','block');
		
		$("div.chatbox").draggable({ disabled: false });	
	  }	
	  
  });
  /*$('.fa-close').click(function(){
    $(this).closest('.chatbox').hide();
  });*/
  var wage = document.getElementById("msg_input");
  wage.addEventListener("keydown", function (e) {
      if (e.keyCode === 13 && !e.shiftKey) {
    	  //checks whether the pressed key is "Enter"
       $('.message-send').trigger('click');
       e.preventDefault();
       return false;
      }
  });
  $('.minclose').click(function(){
	  $('.fa-minus').trigger('click');
	
	  });
});

function isEmail(email) {
	var regex = /^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,4})$/;
	return regex.test(email);
}
var ip ="";
var country_code = "";
var country_name="";
var region_code= "";
var region_name= "";
var city = "";
var zip_code="";
var agent_offline='';
var myVar="";
var firstcontent='';
var myagentStatusTimer="";
var sessionTime=0;
var sessionCheck='';
var agentsatus='';
var thread_ref_id=sessionStorage.getItem("thread_id_run");
$(document).ready(function(){
	
	if(sessionStorage.getItem("login") =="login"){
		 
			
			$(".nameofperson").text(sessionStorage.getItem("agentName"));
			
			 $('.login_box').css('display', 'none');
			 //clearInterval(myVar);
			 //clearInterval(sessionCheck);
			 $('#msg_box').css('display', 'block');
			 sessionStorage.setItem("oldCount",0);
			 $("#msg_body").html("");
				var msg=	sessionStorage.getItem("welcome_msg");
				$("#msg_body").html('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
				'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
				'</div><ul class="chat_message"><li><p>'+msg+
				'<span class="chat_message_time"></span></p></li></ul></div><div class="msg_push"></div>');
			 
			
		 }
	 else if(sessionStorage.getItem("login") =="feedback"){
		 clearInterval(myVar);
		 clearInterval(sessionCheck);
			
			$(".nameofperson").text(sessionStorage.getItem("agentName"));
			
			 $('.login_box').css('display', 'none');

			 $("#msg_body").html("");
			 $('#msg_box').css('display', 'none');
			 $('.feedback_box').css('display', 'block');
		
		 }
	 else{
		
		 var count=0;
		 var mytimer=setInterval(function(){ 
			 count++;
			
			 if(count==10){
				 clearInterval(mytimer);
				// $('.login_box').addClass('popout');
				 $('.login_box').css('display', 'flex'); 
				 /*$('.login_box').animate({top: '0'}, 'slow', function() {
			            $('.login_box').addClass('open');
			        });*/
				
				
				 $('.fa-minus').trigger('click');
				
					/*if(agentsatus=='NA')
						{
						 $('#agentstatus').removeClass('status online');
						 $('#agentstatus').addClass('status donot-disturb');
						
						 $('.web_login').attr('query','query_submit');
						 $('.web_login').html('Submit Query');
						}*/
					
			 }
		 }, 1000);
		/* var counter=0;
			myagentStatusTimer=setInterval(function(){  
				console.log(counter++,agentsatus);
				 Agentstatus();
				 if(agentsatus=='NA')
					{
					 $('#agentstatus').removeClass('status online');
					 $('#agentstatus').addClass('status donot-disturb');
					
					 $('.web_login').attr('query','query_submit');
					 $('.web_login').html('Submit Query');
					}
				 else{
					 $('#agentstatus').removeClass('status donot-disturb');
					 $('#agentstatus').addClass('status online');
					
					 $('.web_login').attr('query','');
					 $('.web_login').html('Start Chat'); 
					 $("#error").html('');
				 }
			 }, 10000);*/
	 }
	
		 $.getJSON('//freegeoip.net/json/?callback=?', function(data) {
			
			  ip =data.ip;
			   country_code = data.metro_code;
			   country_name=data.country_name;
			  region_code= data.latitude+"/"+data.longitude;
			   region_name= data.region_name;
			   city = data.city;
			  zip_code=data.zip_code;
			// console.log(data);
			// Agentstatus();
			});
		 
	
		 for(var i = 1; i <= 5; i++) {
		    	
		    	$('#'+i).css('color','#07D');
		    } 
		 
		 
	if ( $(".login_box").css('display') != 'none'){
	
		$('.fa-minus').trigger('click');
		
		
	}
	
		$('.chat_head').click(function(){
			$('.chat_body').slideToggle('slow');
		});
		$('.msg_head').click(function(){
			$('.msg_wrap').slideToggle('slow');
		});
		
		
		
		$('.user').click(function(){

			$('.msg_wrap').show();
			$('.msg_box').show();
		});
	
		
		 $(".message-send").click(function ()
	   {
			 
	            var msg = jQuery("textarea#msg_input").val();
				
				
				if(thread_ref_id==null){
					thread_ref_id ="0";
				}
				 if (msg != "" && $("#uploadfile").val() == "") {
						msg=msg;
						if(sessionStorage.getItem('group')=='Floral' && (!msg.includes("flower")) && (msg.indexOf('insurance')==-1)&& (msg.indexOf('tax')==-1)){
							msg='I would like to send flowers. '+msg;
							sessionStorage.setItem('group','sent');
						}
						else if(sessionStorage.getItem('group')=='Tax'&& (!msg.includes("tax")) && (!msg.includes("flower"))&& (msg.indexOf('insurance')==-1)){
							msg='I would like to file Tax. '+msg;
							sessionStorage.setItem('group','sent');
						}
						else if(sessionStorage.getItem('group')=='Insurance' && (!msg.includes("insurance")) && (!msg.includes("flower"))&& (msg.indexOf('tax')==-1)){
							msg='I need travel insurance. '+msg;
							sessionStorage.setItem('group','sent');
						}
						else{
							sessionStorage.setItem('group','sent');
						}
						
						jQuery("textarea#msg_input").val('');
						$('#msg_input').attr('disabled', true);
					} else if ($("#uploadfile").val() != "") {
						
						var filename = $("#uploadfile").val();
						msg= filename.split("\\").pop();
						$("#uploadfile").val('');
					}
					else if(msg=='')
						return false;
				if(msg!=''){
				var text=msg;
				text=text.toLowerCase();
				 if (((text.indexOf('.jpg') != -1)|| (text.indexOf('.jpeg') != -1)|| (text.indexOf('.png') != -1) || (text.indexOf('.gif') != -1))) {
						
						$('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="/eda/fileupload/'+thread_ref_id+"/"+msg+'"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					
					}
				 else if((text.indexOf('.docx') != -1)|| (text.indexOf('.doc') != -1)|| (text.indexOf('.txt') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/document.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.pdf') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/pdf.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.ppt') != -1)|| (text.indexOf('.pptx') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/ppt.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.xls') != -1)|| (text.indexOf('.xlsx') != -1)|| (text.indexOf('.csv') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/xls.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.zip') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/zip.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.html') != -1)|| (text.indexOf('.htm') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/html2.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.rar') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/rar.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.mp3') != -1)|| (text.indexOf('.wav') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><audio src="/eda/fileupload/'+thread_ref_id+"/"+msg+'"controls style="margin-top: 40px"></audio>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.mp4') != -1)|| (text.indexOf('.mkv') != -1)|| (text.indexOf('.flv') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('.3gp') != -1)|| (text.indexOf('.mpg') != -1)|| (text.indexOf('.mpeg') != -1) || (text.indexOf('.mpe') != -1) || (text.indexOf('.avi') != -1)){
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+msg+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else if((text.indexOf('https://') != -1)|| (text.indexOf('http://') != -1)|| (text.indexOf('www.') != -1)){
					 var arrayofmsg=text.split(" ");
					 var linkcontent='';
					 $.each(arrayofmsg,function(i,v){
						 if(v.startsWith("http://") || v.startsWith("https://"))
							 {
							 linkcontent+='<a href='+v+' target="_blank" style="color: blue;text-decoration: underline;">'+v +' </a>';
							 }
						 if(!v.startsWith("http://") && !v.startsWith("https://") && v.startsWith("www.")){
							 linkcontent+=' <a href=http://'+v+' target="_blank" style="color: blue;text-decoration: underline;">'+v+' </a>';
						 }
						 if(!v.startsWith("http://") && !v.startsWith("https://") && !v.startsWith("www.")){
							linkcontent+=" "+v+" "; 
						 }
					 })
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><p style="white-space: pre-wrap; word-break: keep-all !important;">'+linkcontent+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
					 
				 }
				 else{
					 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
								'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
								'</div><ul class="chat_message"><li><p style="white-space: pre-wrap; word-break: keep-all !important;">'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
								 
				 }
				 
				 $('#chat').scrollTop($('#chat')[0].scrollHeight);
				
					var sendData = {
							"msg_id" : "",
							"sender_id" : "",
							"device_id" : String(ip),
							"msg_content" : msg,
							"origin_ip" : "",
							"time_stamp" : "",
							"thread_ref_id" : thread_ref_id,
							"parent_id" : 0,
							"tab" : "0",
							"agent_id" : 1,
							"path" : "path",
							"direction" : 'W',
						}
						//$("#loading-indicator").show();
						//console.log(JSON.stringify(sendData))
						jQuery.support.cors = true;
						$.ajax({
							type : "POST",
							contentType : 'application/json',
							dataType : 'json',
							url : base_url + "message/create/",
							data : JSON.stringify(sendData),
							crossDomain : true,
							success : function(result) {
								//console.log(result.thread_ref_id)
								sessionStorage.setItem("thread_id_run",result.thread_ref_id);
								sessionStorage.setItem("feedback_thread",result.thread_ref_id);
								thread_ref_id=sessionStorage.getItem("thread_id_run");
								$('#msg_input').attr('disabled', false);
								document.getElementById('msg_input').focus();
								 myVar = setInterval(function(){ myTimer() }, 5000);
								
								 
							}
						});
				}
				
	       
	    });
		
		
	});
if(thread_ref_id >0){
	  
	
	 myVar = setInterval(function(){ myTimer() }, 5000);
				
	
}

function myTimer() {
			
				var url = "/eda-agent-app/content/"
					+ thread_ref_id; //Change this Url b4 deploying into Bluemix
			// var url = "/content/"+ threadActive;
			jQuery
					.ajax({
						url : url,
						type : "GET",
						dataType : "json",
						success : function(
								resp) {
						//console.log(resp);
							sessionStorage.setItem("newCount",resp[1]);

							var oldcount = sessionStorage
									.getItem("oldCount");

							var newcount = sessionStorage
									.getItem("newCount");
							
							
							if(newcount!=oldcount){
								
								var sendData = {
						
						"thread_id" : thread_ref_id
						
					}
								$.ajax({
									type : "POST",
									contentType : 'application/json',
									dataType : 'json',
									url : base_url+'message/listmessage/',
									data : JSON.stringify(sendData),
									success : function(
											data) {
										var direction='';
										$("#msg_body").html("");
										var msg=	sessionStorage.getItem("welcome_msg");
										$("#msg_body").html('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
										'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
										'</div><ul class="chat_message"><li><p>'+msg+
										'<span class="chat_message_time"></span></p></li></ul></div><div class="msg_push"></div>');
										$.each(data,function(i,v){
											var text=v.msg_content;
											
											if(v.direction=="O"){
												
												
												text=text.toLowerCase();
												sessionTime=v.time_stamp;
												direction=v.direction;
												 if (((text.indexOf('.jpg') != -1)|| (text.indexOf('.jpeg') != -1)|| (text.indexOf('.png') != -1) || (text.indexOf('.gif') != -1))) {
														
														$('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="/eda/fileupload/'+thread_ref_id+"/"+v.msg_content+'"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													
													}
												 else if((text.indexOf('.docx') != -1)|| (text.indexOf('.doc') != -1)|| (text.indexOf('.txt') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/document.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.pdf') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/pdf.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.ppt') != -1)|| (text.indexOf('.pptx') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/ppt.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.xls') != -1)|| (text.indexOf('.xlsx') != -1)|| (text.indexOf('.csv') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/xls.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.zip') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/zip.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.html') != -1)|| (text.indexOf('.htm') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/html2.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.rar') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/rar.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.mp3') != -1)|| (text.indexOf('.wav') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><audio src="/eda/fileupload/'+thread_ref_id+"/"+v.msg_content+'"controls style="margin-top: 40px"></audio>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.mp4') != -1)|| (text.indexOf('.mkv') != -1)|| (text.indexOf('.flv') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.3gp') != -1)|| (text.indexOf('.mpg') != -1)|| (text.indexOf('.mpeg') != -1) || (text.indexOf('.mpe') != -1) || (text.indexOf('.avi') != -1)){
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('https://') != -1)|| (text.indexOf('http://') != -1)|| (text.indexOf('www.') != -1)){
													 var arrayofmsg=text.split(" ");
													 var linkcontent='';
													 $.each(arrayofmsg,function(i,v){
														 if(v.startsWith("http://") || v.startsWith("https://"))
															 {
															 linkcontent+='<a href='+v+' target="_blank" style="color: white;text-decoration: underline;">'+v +' </a>';
															 }
														 if(!v.startsWith("http://") && !v.startsWith("https://") && v.startsWith("www.")){
															 linkcontent+=' <a href=http://'+v+' target="_blank" style="color: white;text-decoration: underline;">'+v+' </a>';
														 }
														 if(!v.startsWith("http://") && !v.startsWith("https://") && !v.startsWith("www.")){
															linkcontent+=" "+v+" "; 
														 }
													 })
													 $('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><p>'+linkcontent+
																'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													
												 }
												 
												else{
													$('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
															'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
															'</div><ul class="chat_message"><li><p style="white-space: pre-wrap; word-break: keep-all !important;">'+v.msg_content+
															'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
												}
											
											}
      
											else{
												
												text=text.toLowerCase();
												direction=v.direction;
												 if (((text.indexOf('.jpg') != -1)|| (text.indexOf('.jpeg') != -1)|| (text.indexOf('.png') != -1) || (text.indexOf('.gif') != -1))) {
														
														$('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="/eda/fileupload/'+thread_ref_id+"/"+v.msg_content+'"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													
													}
												 else if((text.indexOf('.docx') != -1)|| (text.indexOf('.doc') != -1)|| (text.indexOf('.txt') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/document.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.pdf') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/pdf.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.ppt') != -1)|| (text.indexOf('.pptx') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/ppt.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.xls') != -1)|| (text.indexOf('.xlsx') != -1)|| (text.indexOf('.csv') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/xls.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.zip') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/zip.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.html') != -1)|| (text.indexOf('.htm') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/html2.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.rar') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/rar.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.mp3') != -1)|| (text.indexOf('.wav') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><audio src="/eda/fileupload/'+thread_ref_id+"/"+v.msg_content+'"controls style="margin-top: 40px"></audio>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.mp4') != -1)|| (text.indexOf('.mkv') != -1)|| (text.indexOf('.flv') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('.3gp') != -1)|| (text.indexOf('.mpg') != -1)|| (text.indexOf('.mpeg') != -1) || (text.indexOf('.mpe') != -1) || (text.indexOf('.avi') != -1)){
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><a href="/eda-agent-app/downloadfile/'+thread_ref_id+"/"+v.msg_content+'"><img height="100" width="100" src="resources/images/video.png"/></a>'+'<p>'+v.msg_content+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 else if((text.indexOf('https://') != -1)|| (text.indexOf('http://') != -1)|| (text.indexOf('www.') != -1)){
													 var arrayofmsg=text.split(" ");
													 var linkcontent='';
													 $.each(arrayofmsg,function(i,v){
														 if(v.startsWith("http://") || v.startsWith("https://"))
															 {
															 linkcontent+='<a href='+v+' target="_blank" style="color: blue;text-decoration: underline;">'+v +' </a>';
															 }
														 if(!v.startsWith("http://") && !v.startsWith("https://") && v.startsWith("www.")){
															 linkcontent+=' <a href=http://'+v+' target="_blank" style="color: blue;text-decoration: underline;">'+v+' </a>';
														 }
														 if(!v.startsWith("http://") && !v.startsWith("https://") && !v.startsWith("www.")){
															linkcontent+=" "+v+" "; 
														 }
													 })
													 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
																'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
																'</div><ul class="chat_message"><li><p style="white-space: pre-wrap; word-break: keep-all !important;">'+linkcontent+'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
													 
												 }
												 
												else{
												
												$('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
														'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
														'</div><ul class="chat_message"><li><p style="white-space: pre-wrap; word-break: keep-all !important;">'+v.msg_content+
														'<span class="chat_message_time">'+time(v.time_stamp)+'</span></p></li></ul></div>').insertBefore('.msg_push');
														}
											}
			       
										});
										
										clearInterval(sessionCheck);
										sessionStorage.setItem("oldCount",(sessionStorage.getItem("newCount")));
										 $('#chat').scrollTop($('#chat')[0].scrollHeight);
										 if(direction=='O')
										 sessionCheck = setInterval(function(){ mySession(sessionTime) }, 60000);
										
									}
								})
										
									
							}
							
						}
					})
}
function mySession(sessionTime){
	//console.log(sessionTime);
	if((new Date().getTime()-sessionTime)>300000){
		clearInterval(sessionCheck);
		jQuery("textarea#msg_input").val('This session has been closed by agent.@session_logout')
		$(".closechat").trigger('click');		
		
		return false;
		//clearInterval(myVar);
		//clearInterval(sessionCheck);
	}
}

$(function() {
		$("#web_login")
				.click(function() {
					
					var agentName = $("#web_name").val();
	                var password = $("#web_email").val();
	                var errorTxt = '';
	                if (agentName=="") {
	                	errorTxt += 'User name ';
	                }
	                if(password==""){
	                	errorTxt += (errorTxt != '') ? '& Email ID ' : 'Email ID ';
	                }
	                if($('#sel1').prop('selectedIndex')==0){
	                	errorTxt += (errorTxt != '') ? '& Department selection ' : 'Department selection';	
	                }
	                if($('.web_login').attr('query') !="" && jQuery("textarea.query").val()=="")
	                	{
	                	errorTxt += (errorTxt != '') ? '& Query ' : 'Query ';
	                	}
	                
	                errorTxt = (errorTxt != '') ? errorTxt + 'is required' : '';
	                
	                if(errorTxt){
	                	$("#error").html(errorTxt);
	                	return false;
	                }
	                else{
	                	
	                	if(!isEmail(password))
	                		{
	                		$("#error").html("EMail ID is Invalid.");
		                	return false;
	                		
	                		}
	                	$("#error").html("");
	                	
	                	var profile ={
	                			"email_id" : password,
								"first_name" : agentName,
								"last_name" :"",
								"address":"",
								"mobile_number": "",
								"anniversary":"",
								"country" :"From Web",
								"pin" :"00000"
	                	}
	                	
	                	agent_offline=$('.web_login').attr('query');
	                	var sendData = {
								
								"device_id" : String(ip),
								"profile" :profile,
								"model_name" : String(country_code),
								"gcm_reg_key" : "0",
								"manufacturer" :country_name,
								"os_name" : String(region_code),
								"os_version" :region_name,
								"release" : city,
								"agent_offline":agent_offline,
								"user_query":jQuery("textarea.query").val(),
								"project_dept": $('#sel1').val(),
							}
							//$("#loading-indicator").show();
						//console.log(JSON.stringify(sendData));
	                	//return false;

							

							jQuery.support.cors = true;
							$.ajax({
								type : "POST",
								contentType : 'application/json',
								dataType : 'json',
								url : base_url + "webkey/create/",
								data : JSON.stringify(sendData),
								crossDomain : true,
								async :false,
								success : function(result) {
									
									
								}
							});
							jQuery("textarea#msg_input").val('');
							if($('.web_login').attr('query') !=""){
								$("#web_name").val("");
				                $("#web_email").val("");
				                $('#sel1').prop('selectedIndex',0);
								jQuery("textarea.query").val("");
								$("#error").html("Your query has been submitted. We will get back to you in the next 24 hours.");
							}
							else{
								sessionStorage.setItem("login","login");
								sessionStorage.setItem("agentName",agentName);
								sessionStorage.setItem("group",$('#sel1').val());
								clearInterval(myagentStatusTimer);
								firstcontent ="Welcome "+agentName+"! This is Eda. How can I assist You ?";
								
								sessionStorage.setItem("welcome_msg",firstcontent);
								$("#msg_body").html("");
					 			var msg=sessionStorage.getItem("welcome_msg");
					 			$("#msg_body").html('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
					 			'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
					 			'</div><ul class="chat_message"><li><p>'+msg+
					 			'<span class="chat_message_time"></span></p></li></ul></div><div class="msg_push"></div>');

								$(".nameofperson").text(sessionStorage.getItem("agentName"));
								 $('#msg_box').css('display', 'flex');
								 $('.login_box').css('display', 'none');
									
							//$('.chatbox-icons a:first-child i').removeClass('fa-plus').addClass('fa-minus');
									 $("#web_name").val("");
						                $("#web_email").val("");
						                $('#sel1').prop('selectedIndex',0);
										jQuery("textarea.query").val("");
										if($('#msg_box').hasClass('chatbox-min')){
											$('#msg_box').removeClass('chatbox-min')
											$('.chatbox-icons a:first-child i').removeClass('fa-plus').addClass('fa-minus');		
											$('#msg_box').find('.popup-head').removeClass('hide');
											$('#msg_box').find('.chat-input-holder').removeClass('hide');
											$('#msg_box').find('.attachment-panel').removeClass('hide');
											$('#msg_box').find('.attachment-panel').next().removeClass('hide');
											$('#msg_box').find('#chat').removeClass('hide');	
											$('#msg_box').find('.chat-messages').css('display','flex');
											$('#msg_box').find('.footer').css('display','block');
											
											$("div.chatbox").draggable({ disabled: false });
											
										}	
							}
						
										
	                }
					
						})
						$(".closechat")
				.click(function() {
					
					
					var options = {
							Ok : "Yes",
							Cancel : "No"
						}
						UIkit.modal
								.confirm(
										'<div class=\'uk-text-center\'><div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
												+ "Do you want to end this chat?",
										closechat, cancelclosechat);
				
					if(jQuery("textarea#msg_input").val() =="This session has been closed by agent.@session_logout"){
						$(".js-modal-confirm").trigger('click');
						return false;
					}
					
					
					function closechat(){
						clearInterval(myVar);
						clearInterval(sessionCheck);
						 var direction='W';
						 if(!(thread_ref_id == 0 || thread_ref_id ==null || thread_ref_id =="0")){
							   var msg = jQuery("textarea#msg_input").val();	
						
							
								if(msg =="This session has been closed by agent.@session_logout")
									{
									msg="This session has been closed by user.";
									direction='O';
									}
								else{
									msg = "This session has been closed by user.";
								}
								jQuery("textarea#msg_input").val('');
								
								if(msg!='')
									 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
												'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
												'</div><ul class="chat_message"><li><p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
												
								if(msg!=''){
									var sendData = {
											"msg_id" : "",
											"sender_id" : "",
											"device_id" : String(ip),
											"msg_content" : msg,
											"origin_ip" : "",
											"time_stamp" : "",
											"thread_ref_id" : thread_ref_id,
											"parent_id" : 0,
											"tab" : "0",
											"agent_id" : 1,
											"path" : "path",
											"direction" : 'W',
										}
										//$("#loading-indicator").show();
										
										jQuery.support.cors = true;
										$.ajax({
											type : "POST",
											contentType : 'application/json',
											dataType : 'json',
											url : base_url + "message/create/",
											data : JSON.stringify(sendData),
											crossDomain : true,
											success : function(result) {
												sessionStorage.setItem("thread_id_run","0");
												thread_ref_id=sessionStorage.getItem("thread_id_run");
											}
										});
								}
							}
						 sessionStorage.setItem("thread_id_run","0");
						 sessionStorage.setItem("login","feedback");
						 clearInterval(sessionCheck);
						 if(direction=='O'){
							 UIkit.modal
								.alert(
										'<div class=\'uk-text-center\'><div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
												+ "This session has been closed by Agent."); 
							
						 }
						
						 $("#msg_body").html("");
						 for(var i = 1; i <= 5; i++) {
						    	
						    	$('#'+i).css('color','#07D');
						    } 
						$('#msg_box').css('display', 'none');
						$('.feedback_box').css('display', 'block');
						if($('.feedback_box').hasClass('chatbox-min')){
							$('.feedback_box').removeClass('chatbox-min')
							$('.chatbox-icons a:first-child i').removeClass('fa-plus').addClass('fa-minus');		
							$('.feedback_box').find('.popup-head').removeClass('hide');
							$('.feedback_box').find('.chat-input-holder').removeClass('hide');
							$('.feedback_box').find('.attachment-panel').removeClass('hide');
							$('.feedback_box').find('.attachment-panel').next().removeClass('hide');
							$('.feedback_box').find('#chat').removeClass('hide');	
							$('.feedback_box').find('.chat-messages').css('display','flex');
							$('.feedback_box').find('.footer').css('display','block');
							
							$("div.chatbox").draggable({ disabled: false });
							
						}
					}
					function cancelclosechat(){
						return false;
					}
					
				})
				$("#closechat")
				.click(function() {
					
					var options = {
							Ok : "Yes",
							Cancel : "No"
						}
						UIkit.modal
								.confirm(
										'<div class=\'uk-text-center\'><div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
												+ "Do you want to close this chat?",
										closechat, cancelclosechat);
					
					function closechat(){
						clearInterval(myVar);
						clearInterval(sessionCheck);
						sessionStorage.setItem("login","logout");
						 if(!(thread_ref_id == 0 || thread_ref_id ==null || thread_ref_id =="0")){
								
								var msg = "This session has been closed by user.";
								
								if(msg!='')
									 $('<div class="chat_message_wrapper chat_message_right"><div class="chat_user_avatar">'+
												'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Shauna.jpg" class="md-user-image"></a>'+
												'</div><ul class="chat_message"><li><p>'+msg+'<span class="chat_message_time">'+time(new Date().getTime())+'</span></p></li></ul></div>').insertBefore('.msg_push');
												
								if(msg!=''){
									var sendData = {
											"msg_id" : "",
											"sender_id" : "",
											"device_id" : String(ip),
											"msg_content" : msg,
											"origin_ip" : "",
											"time_stamp" : "",
											"thread_ref_id" : thread_ref_id,
											"parent_id" : 0,
											"tab" : "0",
											"agent_id" : 1,
											"path" : "path",
											"direction" : "W"
										}
										//$("#loading-indicator").show();
										
										jQuery.support.cors = true;
										$.ajax({
											type : "POST",
											contentType : 'application/json',
											dataType : 'json',
											url : base_url + "message/create/",
											data : JSON.stringify(sendData),
											crossDomain : true,
											success : function(result) {
												sessionStorage.setItem("thread_id_run","0");
												thread_ref_id=sessionStorage.getItem("thread_id_run");
											}
										});
								}
							}
						 sessionStorage.setItem("thread_id_run","0");
						 
						 $("#msg_body").html("");
						 $('#msg_box').css('display', 'none');
							$('.feedback_box').css('display', 'none');
							$('.login_box').css('display', 'block');
							for(var i = 1; i <= 5; i++) {
						    	
						    	$('#'+i).css('color','#07D');
						    } 
							 $("#web_name").val("");
			                $("#web_email").val("");
			                $('#sel1').prop('selectedIndex',0);
							jQuery("textarea.query").val("");
			                sessionStorage.setItem("feedback_thread","0");
					}
					function cancelclosechat(){
						return false;
					}
					
				})
				
				$(".loginchat").click(function() {
					
					var options = {
							Ok : "Yes",
							Cancel : "No"
						}
						UIkit.modal
								.confirm(
										'<div class=\'uk-text-center\'><div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
												+ "Do you want to close this chat?",
									closechat, cancelclosechat);
					function closechat(){
						clearInterval(myVar);
						clearInterval(sessionCheck);
						sessionStorage.setItem("login","logout");
						/*$("#msg_body").html("");
						var msg=sessionStorage.getItem("welcome_msg");
						$("#msg_body").html('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
						'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
						'</div><ul class="chat_message"><li><p>'+msg+
						'<span class="chat_message_time"></span></p></li></ul></div><div class="msg_push"></div>');*/
						 sessionStorage.setItem("thread_id_run","0");
						$('#msg_box').css('display', 'none');
						$('.feedback_box').css('display', 'none');
						$('.login_box').css('display', 'block');
						for(var i = 1; i <= 5; i++) {
					    	
					    	$('#'+i).css('color','#07D');
					    } 
						 $("#web_name").val("");
		                $("#web_email").val("");
		                $('#sel1').prop('selectedIndex',0);
						jQuery("textarea.query").val("");
		                sessionStorage.setItem("feedback_thread","0");
					}
					function cancelclosechat(){
						return false;
					}
					
					
				});
		$(".btnfeedback").click(function() {
			
			
			var agentName = jQuery("textarea#feedback_input").val();
            var password = $(".selectedstar").attr('id');
            //console.log(password)
            var errorTxt = '';
            if (agentName=="") {
            	errorTxt += 'Feedback comments ';
            }
            if(password=="" || password==undefined ){
            	errorTxt += (errorTxt != '') ? '& Rating ' : 'Rating ';
            }
            errorTxt = (errorTxt != '') ? errorTxt + 'is required' : '';
            
            if(errorTxt){
            	$("#feedbackerror").html(errorTxt);
            	return false;
            }
            else{
            	 
            	var sendData = {
						
						"device_id" : String(ip),
						"thread_id" : sessionStorage.getItem("feedback_thread"),
						"feedbackcommand" : agentName,
						"star" : password	
					}
					//$("#loading-indicator").show();
					
					jQuery.support.cors = true;
					$.ajax({
						type : "POST",
						contentType : 'application/json',
						dataType : 'json',
						url : base_url + "webchat/feedback/",
						data : JSON.stringify(sendData),
						crossDomain : true,
						success : function(result) {
							UIkit.modal
			 				.alert('<div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
			 						+ "Thank you for your valuable feedback."); 
			 			clearInterval(myVar);
			 			clearInterval(sessionCheck);
			 			
			 			$("#msg_body").html("");
			 			var msg=sessionStorage.getItem("welcome_msg");
			 			$("#msg_body").html('<div class="chat_message_wrapper chat_message_left"><div class="chat_user_avatar">'+
			 			'<a href="javascript:;" target="_blank" ><img alt="Ramya" title="Ramya"  src="resources/images/Arnold.jpg" class="md-user-image"></a>'+
			 			'</div><ul class="chat_message"><li><p>'+msg+
			 			'<span class="chat_message_time"></span></p></li></ul></div><div class="msg_push"></div>');
						}
					});
					for(var i = 1; i <= 5; i++) {
				    	
				    	$('#'+i).css('color','#07D');
				    } 
            	$('#msg_box').css('display', 'none');
				$('.feedback_box').css('display', 'none');
				$('.login_box').css('display', 'block');
				sessionStorage.setItem("login","logout");
				 $("#web_name").val("");
                $("#web_email").val("");
                jQuery("textarea#feedback_input").val("");
                $("#feedbackerror").html("");
                $('.fa.fa-star.selectedstar').removeClass('selectedstar');
                sessionStorage.setItem("feedback_thread","0");
            }
			
		});
		$(".fa.fa-star").click(function() {
			for(var i = 1; i <= 5; i++) {
		    	
		    	$('#'+i).css('color','#07D');
		    }
			$('.fa.fa-star.selectedstar').removeClass('selectedstar');
	    $(this).addClass('selectedstar');
	    var star=$(".selectedstar").attr('id');
	    //console.log(typeof(parseInt(star)))
	   for(var i = 1; i <= parseInt(star); i++) {
	    
	    	$('#'+i).css('color','gold');
	    }
		});
});
function time(ms) {
	   
	 var d=new Date(ms);
	 var hour = d.getHours() == 0 ? 12 : (d.getHours() > 12 ? d.getHours() - 12 : d.getHours());
	 var min = d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes();
	 var ampm = d.getHours() < 12 ? 'AM' : 'PM';
	 return hour + ':' + min + ' ' + ampm;
	}	
function readURL(input) {
	var threadid = sessionStorage.getItem('thread_id_run');
	$("#thread").val(threadid);
	
	if(threadid=="0"){
		UIkit.modal
		.alert('<div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
				+ "Please specify your query before you send/attach any files."); 
		return false;
	}
		
		filesize = "";
		filename = "";
		text = "";
		formData = "";
		
		filesize = $('input[type=file]')[0].files[0];
		filename = $("#uploadfile").val();
		text = filename.split("\\").pop();
text=text.toLowerCase();
		//console.log(formData)

		if ((filesize.size / 1024 / 1024) > 25) {
			//alert(1)
			UIkit.modal
					.alert('<div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
							+ 'File size should not exceeds 25 MB.');
							//alert("File size should not exceeds 25 MB.")
			return true;
		}
		if (text.indexOf('.exe') != -1) {
			//alert(2)
			 UIkit.modal
					.alert('<div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
							+ "You Are Not Allow To Send Application Files(.EXE)."); 
			//alert("You Are Not Allow To Send Application Files(.EXE)");
			return true;
		} 
		
		else if (!((text.indexOf('.doc') != -1) || (text.indexOf('.docx') != -1) || (text.indexOf('.pdf') != -1)|| (text.indexOf('.pptx') != -1)
				|| (text.indexOf('.xls') != -1) || (text.indexOf('.xlsx') != -1) || (text.indexOf('.zip') != -1) || (text.indexOf('.rar') != -1)
				|| (text.indexOf('.rtf') != -1)|| (text.indexOf('.wav') != -1) || (text.indexOf('.mp3') != -1)|| (text.indexOf('.gif') != -1)
				|| (text.indexOf('.jpg') != -1)|| (text.indexOf('.jpeg') != -1)|| (text.indexOf('.png') != -1)|| (text.indexOf('.txt') != -1)
				|| (text.indexOf('.3gp') != -1)|| (text.indexOf('.mpg') != -1)|| (text.indexOf('.mpeg') != -1)|| (text.indexOf('.mpe') != -1)
				|| (text.indexOf('.mp4') != -1) || (text.indexOf('.avi') != -1) || (text.indexOf('.AVI') != -1))) {
				//alert(2)
			UIkit.modal
						.alert('<div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
								+ "The attached file format is not supported in the current system!."); 
				//alert("The attached file format is not supported in the current system!");
				return true;
			}
		
		else {
			
			
			//alert(3)
			var options = {
				Ok : "Yes",
				Cancel : "No"
			}
			UIkit.modal
					.confirm(
							'<div class=\'uk-text-center\'><div class=\'uk-text-center\'><img class="" src="resources/images/edanewlogo.png" alt="" style="width: 68px;margin-bottom: 10px;"><br>'
									+ "Are you sure you want to send file ?",
							uploadimage, cancelupload);
	
			
		}

		function uploadimage() {
			
			
			
			
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function(e) {
					$('#blah').attr('src', e.target.result).width(150).height(200);
				};
				reader.readAsDataURL(input.files[0]);
			}

			formData = new FormData();
			formData.append('file', $('input[type=file]')[0].files[0]);
			formData.append('threadid', threadid);
			$.ajax({
				url : '/eda-agent-app/uploadFile',
				// url : '/uploadFile',
				data : formData,
				processData : false,
				contentType : false,
				type : 'POST',
				success : function(data) {
					
					$(".message-send").trigger("click");
					
				}
			});
		}
		function cancelupload() {
			//return false;
			//$('.file_upload_click').trigger('change')
			$("#uploadfile").trigger("click");

		}

	}
function Agentstatus(){
	
	var result	= '';
			
        jQuery.support.cors = true;
				$
						.ajax({
							type : "GET",
							contentType : 'application/json',
							dataType : 'json',
							url :base_url+"agent/status/"+ip,
							
							crossDomain : true,
           
            success : function(data) {
            	agentsatus=data;	
            	//console.log(agentsatus);
            },
			   error  : function (err) {
                       
				   agentsatus=err.responseText;
				  // console.log(agentsatus);
                   }
        }); 
				
}

$("#sel1").on("change",function() {
	  if($('#sel1').prop('selectedIndex')!=0){
		 
		  jQuery.support.cors = true;
			$
					.ajax({
						type : "GET",
						contentType : 'application/json',
						dataType : 'json',
						url :base_url+"project/agent/status/"+$('#sel1').prop('selectedIndex'),
						
						crossDomain : true,
     
      success : function(data) {
      	agentsatus=data;	
      	//console.log(agentsatus);
      },
		   error  : function (err) {
                 
			   agentsatus=err.responseText;
			  
			   if(agentsatus=='NA')
				{
				 $('#agentstatus').removeClass('status online');
				 $('#agentstatus').removeClass('status away');
				 $('#agentstatus').addClass('status donot-disturb');
				
				 $('.web_login').attr('query','query_submit');
				 $('.web_login').html('Submit Query');
				 $("#error").html('Agent in department '+$('#sel1').val()+' are either busy or unavailable at this time. Please submit your query, we will respond in 24 hours.');
				}
			 else{
				 $('#agentstatus').removeClass('status donot-disturb');
				 $('#agentstatus').removeClass('status away');
				 $('#agentstatus').addClass('status online');
				
				 $('.web_login').attr('query','');
				 $('.web_login').html('Start Chat'); 
				 $("#error").html('');
			 }
             }
  }); 
	  }
})



/*$("html").on("contextmenu", function(e) {
	e.preventDefault();
	return false;
});

document.onkeydown = function (e) {
    e = e || window.event;//Get event
    if (e.ctrlKey) {
        var c = e.which || e.keyCode;//Get key code
        switch (c) {
            case 83://Block Ctrl+S
            case 87://Block Ctrl+W --Not work in Chrome
            case 16://Block Ctrl+Shift
            case 73://Block Ctrl+I
                e.preventDefault();     
                e.stopPropagation();
            break;
        }
    }
    if(e.which == 123 || e.keyCode == 123){
    	e.preventDefault();     
        e.stopPropagation();
    }
}; */